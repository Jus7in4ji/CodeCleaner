// ComplexCode8: Checking palindrome with redundant string operations
import java.util.Scanner;
class PaliX{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.println("Enter string:");
String str=sc.next(),rev="";
int i=str.length();
while(--i>=0) rev+=str.charAt(i);
System.out.println(str.equals(rev)?"Palindrome":"Not Palindrome");
// Unused variable
int dummy=5;
}
}