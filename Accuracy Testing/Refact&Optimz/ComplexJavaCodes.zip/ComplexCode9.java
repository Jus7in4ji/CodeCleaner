// ComplexCode9: Binary search with redundant conditions
import java.util.Scanner;
class BSrch{
static int binarySearch(int arr[], int l, int r, int x){
while(l<=r){
int m=l+(r-l)/2;
if(arr[m]==x) return m;
if(arr[m]<x) l=m+1;
else r=m-1;
}
return -1;
}
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
int arr[]={2,3,4,10,40};
System.out.println("Enter number to search:");
int x=sc.nextInt();
int result=binarySearch(arr,0,arr.length-1,x);
System.out.println(result==-1?"Not Found":"Found at index "+result);
// Unused operation
int junk = result * 2;
}
}