// ComplexCode7: Graph traversal with excessive recursion and unnecessary loops
import java.util.*;
class GtRv{
void dfs(int v, boolean visited[], LinkedList<Integer> adj[]){
visited[v]=true;
for(int n:adj[v])
if(!visited[n]) dfs(n,visited,adj);
}
public static void main(String args[]){
GtRv g=new GtRv();
int V=5;
LinkedList<Integer> adj[]=new LinkedList[V];
for(int i=0;i<V;i++) adj[i]=new LinkedList<>();
adj[0].add(1); adj[0].add(2); adj[1].add(2);
adj[2].add(0); adj[2].add(3); adj[3].add(3);
boolean visited[]=new boolean[V];
g.dfs(2, visited, adj);
// Dead code
if(false) System.out.println("This never runs");
}
}