// ComplexCode6: Dijkstra's algorithm with redundant operations
import java.util.*;
class dijkAlgo{
static final int V=5;
int minDist(int dist[], Boolean sptSet[]){
int min=Integer.MAX_VALUE, min_index=-1;
for(int v=0;v<V;v++)
if(!sptSet[v]&&dist[v]<=min){min=dist[v];min_index=v;}
return min_index;
}
void dijkstra(int graph[][], int src){
int dist[]=new int[V];
Boolean sptSet[]=new Boolean[V];
Arrays.fill(dist, Integer.MAX_VALUE);
Arrays.fill(sptSet, false);
dist[src]=0;
for(int count=0;count<V-1;count++){
int u=minDist(dist,sptSet);
sptSet[u]=true;
for(int v=0;v<V;v++)
if(!sptSet[v]&&graph[u][v]!=0&&dist[u]!=Integer.MAX_VALUE&&dist[u]+graph[u][v]<dist[v])
dist[v]=dist[u]+graph[u][v];
}
System.out.println("Vertex Distances: "+Arrays.toString(dist));
}
public static void main(String args[]){
int graph[][]={{0,9,0,0,0},{9,0,10,0,0},{0,10,0,11,0},{0,0,11,0,12},{0,0,0,12,0}};
new dijkAlgo().dijkstra(graph,0);
// Unused variable
int xyz = 999;
}
}