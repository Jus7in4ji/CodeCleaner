// ComplexCode2: Bubble sort with redundant operations
import java.util.Scanner;
class qWeRtY{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.println("Enter array size:");
int n=sc.nextInt(),xx=7;
int arr[]=new int[n];
for(int i=0;i<n;i++) arr[i]=sc.nextInt();
// Bubble sort with unnecessary swaps
for(int i=0;i<n-1;i++)
for(int j=0;j<n-i-1;j++)
if(arr[j]>arr[j+1]){
int temp=arr[j]; arr[j]=arr[j+1]; arr[j+1]=temp; xx++;
}
System.out.println("Sorted Array:");
for(int i:arr)System.out.print(i+" ");
}
}