// ComplexCode1: Fibonacci with unnecessary operations and bad naming
import java.util.Scanner;
class xYzA {
public static void main(String args[]){
Scanner in=new Scanner(System.in);
System.out.println("Enter n:");
int aa=in.nextInt(),bb=0,cc=1,dd=0,zz=5;
System.out.println("Fibonacci:");
for(int i=0;i<aa;i++){
System.out.print(bb+" ");
dd=bb+cc;
bb=cc;
cc=dd;
// Unused variable
int junk=zz+1;
}
// Dead Code
if(false){System.out.println("Useless Code");}
}
}