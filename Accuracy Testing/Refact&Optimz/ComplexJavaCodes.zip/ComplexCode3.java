// ComplexCode3: Prime number check with inefficient logic and useless vars
import java.util.Scanner;
class AbCdEfG{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.println("Enter number:");
int n=sc.nextInt(),aa=0,bb=1;
boolean isPrime=true;
for(int i=2;i<n/2;i++){
if(n%i==0){isPrime=false;break;} aa++;
}
System.out.println(isPrime?"Prime":"Not Prime");
// Dead Code
if(false){System.out.println("Never runs");}
}
}