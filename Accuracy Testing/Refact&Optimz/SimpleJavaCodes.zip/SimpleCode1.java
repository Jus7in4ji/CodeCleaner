// SimpleCode1: Sum of numbers with dead code and poor formatting
import java.util.*;

class sumcalc {
public static void main(String args[]) {
Scanner sc=new Scanner(System.in);
int a,b,c=0;
System.out.println("Enter two numbers:");
a=sc.nextInt();b=sc.nextInt();
c=a+b;
System.out.println("Sum: "+c);
// Dead Code: This will never execute
if(false) { System.out.println("Dead Code"); }
// Unused variable
int unused = 10;
}
}