// SimpleCode5: Swapping two numbers inefficiently
import java.util.Scanner;
class swapnums{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.println("Enter two numbers:");
int a=sc.nextInt(),b=sc.nextInt(),temp=0;
System.out.println("Before swap: "+a+" "+b);
temp=a;
a=b;
b=temp;
System.out.println("After swap: "+a+" "+b);
// Unused variable
int unused=5;
}
}