// SimpleCode4: Checking even or odd with messy formatting
import java.util.Scanner;
class checknum{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.println("Enter a number:");
int num=sc.nextInt();
// Useless Condition
if(num%2==0)System.out.println("Even");
else System.out.println("Odd");
// Dead code
if(false){System.out.println("Never runs");}
}
}