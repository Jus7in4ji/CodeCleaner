// SimpleCode2: Find max of three numbers with issues
import java.util.Scanner;
class maxfinder {
public static void main(String args[]) {
Scanner sc=new Scanner(System.in);
int x,y,z,max;
System.out.println("Enter three numbers:");
x=sc.nextInt();
y=sc.nextInt();
z=sc.nextInt();
max=x;
if(y>max) max=y;
if(z>max) max=z;
System.out.println("Max: "+max);
// Dead Code: Will never execute
if(false) { System.out.println("Unreachable"); }
// Unused Variable
int dummy = 100;
}
}