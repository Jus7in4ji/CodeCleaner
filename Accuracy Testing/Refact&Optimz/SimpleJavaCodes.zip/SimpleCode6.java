// SimpleCode6: Printing first N numbers with an inefficient loop
import java.util.Scanner;
class printnums{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.println("Enter a number:");
int n=sc.nextInt();
// Inefficient loop with unnecessary condition
for(int i=1;i<=n;i++){
if(i>0) System.out.println(i);
}
// Dead Code
if(false){System.out.println("This won't print");}
}
}