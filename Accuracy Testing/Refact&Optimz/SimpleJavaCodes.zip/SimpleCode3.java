// SimpleCode3: Factorial calculation with inefficiencies
import java.util.Scanner;
class factorialcalc {
public static void main(String args[]) {
Scanner sc=new Scanner(System.in);
System.out.println("Enter a number:");
int num=sc.nextInt();
int fact=1;
// Unoptimized loop
for(int i=num;i>0;i--) fact*=i;
System.out.println("Factorial: "+fact);
// Dead Code
if(false) { System.out.println("This code never runs"); }
}
}