// SimpleCode10: Basic Calculator with poor structure
import java.util.Scanner;
class calculator{
public static void main(String args[]){
Scanner sc=new Scanner(System.in);
System.out.println("Enter two numbers:");
int a=sc.nextInt(),b=sc.nextInt();
System.out.println("Enter operation (+,-,*,/):");
char op=sc.next().charAt(0);
if(op=='+') System.out.println(a+b);
else if(op=='-') System.out.println(a-b);
else if(op=='*') System.out.println(a*b);
else if(op=='/') System.out.println(a/b);
else System.out.println("Invalid operator");
// Unused variable
int unused=20;
}
}