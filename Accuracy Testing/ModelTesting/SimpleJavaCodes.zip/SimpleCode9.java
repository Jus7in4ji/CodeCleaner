// SimpleCode9: Array Sorting
import java.util.Arrays;

public class SimpleCode9 {
    public static void main(String[] args) {
        int[] arr = {5, 2, 8, 1, 3};
        Arrays.sort(arr);
        System.out.println("Sorted Array: " + Arrays.toString(arr));
    }
}